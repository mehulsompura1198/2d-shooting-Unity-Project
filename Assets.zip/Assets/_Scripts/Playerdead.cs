﻿using UnityEngine;
using System.Collections;

public class Playerdead : MonoBehaviour {

	public float Speed=0.000001f;
	void Start () {
		//PlayerFalldown (); 
		iTween.MoveTo (gameObject, iTween.Hash ( "position", transform.position +new Vector3(1,-2,0), "time", 0.2f,"oncomplete","playerFalling"));
		//Invoke ("playerFalling", 0.3f);
		//gameObject.name="Dead";
	}
	
//	void PlayerFalldown (){
//
//		//iTween.RotateAdd(gameObject , iTween.Hash("amount", new Vector3(0,0,-90),"time",1.5f ));
//	}
	void playerFalling()
	{
		print ("Playerfalling method calling here ");
		iTween.MoveTo (gameObject, iTween.Hash (  "position", transform.position +Vector3.up*-2, "time", 0.2f));
	}
	void Update () {

	
	}
}
