﻿using UnityEngine;
using System.Collections;

public class MainuMenuController : MonoBehaviour
{

		// Use this for initialization
		public Camera MainCam;
		public GameObject Tittle;
		public Renderer playBtnRender, moreBtnRender, reviewBtnRender, creditsBtnRender, CreditsbackBtnRender, StorebackBtnRender, exitBtnRender, StoreBtnRender;
		public Texture[] playBtnTexture, moreBtnTexture, reviewBtnTexture, creditsBtnTexture, CreditsbackBtnTexture, StorebackBtnTexture, exitBtnTexture, StoreBtnTexture;
		public GameObject mainMenu, creditsMenu, storeMenu, LoadingMenu;
	
		void Start ()
		{

				iTween.PunchScale (Tittle, iTween.Hash ("Amount", new Vector3 (0.3f, 0.3f, 0.3f), "time", 0.3f, "Eesetype", iTween.EaseType.easeInOutBack, "looptype", iTween.LoopType.loop));
				Time.timeScale = 1;
		
				#if UNITY_IOS
					 
		exitBtnRender.enabled = false;
		exitBtnRender.collider.enabled = false;
				#endif
		Vector2 screenAspectRatio = AspectRatio.GetAspectRatio (Screen.width, Screen.height);
		
		if (screenAspectRatio == new Vector2 (4, 3)) {
			Camera.main.orthographicSize=6;

		}
		
		
		if (screenAspectRatio == new Vector2 (3, 2)) {
			Camera.main.orthographicSize=5;

		}
		if (screenAspectRatio == new Vector2 (16, 10)) {

			Camera.main.orthographicSize=5;
		}
		if (screenAspectRatio == new Vector2 (16, 9)) {
			
			Camera.main.orthographicSize=4.5f;
		}
		if (screenAspectRatio == new Vector2 (5, 4)) {

			Camera.main.orthographicSize=6;
			
		}

		}
	
		string hitObjName;
		bool isOnstoreMenu = false ;
		
		void Update ()
		{
				if (Input.GetKeyUp (KeyCode.Escape)) {
						if (!isOnstoreMenu) {
								Application.Quit ();
						} else {

								iTween.MoveTo (storeMenu, new Vector3 (50, 0, 0), 0.5f);
								iTween.MoveTo (mainMenu, new Vector3 (0, 0.5f, 0), 0.5f);
						}
				}
				RaycastHit hitObject;
		
				if (Input.GetKeyUp (KeyCode.Mouse0)) {
						OriginalTextures ();
						Ray rayObj = MainCam.ScreenPointToRay (Input.mousePosition);
						if (Physics.Raycast (rayObj, out hitObject)) {
								hitObjName = hitObject.collider.name;
								switch (hitObjName) {
								case "CreditsBtn":
										
										iTween.MoveTo (creditsMenu, new Vector3 (0, 0, 0), 0.5f);
										iTween.MoveTo (mainMenu, new Vector3 (-20, 0, 0), 0.5f);

										break;
					
				case "MoreBtn":
					#if UNITY_ANDROID
					

					//Application.OpenURL("https://play.google.com/store/apps/developer?id=DevAndroid2 ");
					#endif
					#if UNITY_IOS
					
					
					Application.OpenURL("");
					#endif
					#if UNITY_WP8
					
					
					Application.OpenURL("");
					#endif
					#if UNITY_WEBPLAYER
					
					
					Application.OpenURL("https://www.assetstore.unity3d.com/en/#!/publisher/920");
					#endif
					
					break;
					
								case "PlayBtn":
										iTween.MoveTo (LoadingMenu, new Vector3 (0, 1, 0), 0.5f);
										iTween.MoveTo (mainMenu, new Vector3 (-20, 0, 0), 0.5f);
										Invoke ("GamePlay", 1f);
										//Application.LoadLevel ("Jetpackjoyride");
										
										break;
					
								case "ReviewBtn":
										
							//			Application.OpenURL ("https://play.google.com/store/apps/developer?id=ADVEN+DROID");
							//			#if UNITY_IPHONE
							//				Application.OpenURL("https://play.google.com/store/apps/developer?id=Ace+Games");
							//			# elif UNITY_ANDROID
							//				Application.OpenURL("https://play.google.com/store/apps/developer?id=Ace+Games");
							//			#elif UNITY_WP8
							//				Application.OpenURL("https://play.google.com/store/apps/developer?id=Ace+Games");
							//			#endif
										break;
								case "StoreBtnBack":
										
										//if (storeMenu.transform.position.x <= 0) {
										iTween.MoveTo (storeMenu, new Vector3 (50, 0, 0), 0.5f);
										iTween.MoveTo (mainMenu, new Vector3 (0, 0.5f, 0), 0.5f);

										isOnstoreMenu = false;
										break;	
								case "CreditsBtnBack":
					
										isOnstoreMenu = true;
										iTween.MoveTo (creditsMenu, new Vector3 (-20, 0, 0), 0.5f);
										iTween.MoveTo (mainMenu, new Vector3 (0, 0.5f, 0), 0.5f);
									
					
										break;	
								case "ExitBtn":
										
										//print ("Exit");
										Application.Quit ();
										break;
								case "StoreBtn":
										
										iTween.MoveTo (storeMenu, new Vector3 (0, 1, 0), 0.5f);
										iTween.MoveTo (mainMenu, new Vector3 (20, 0, 0), 0.5f);
										break;
					
								}
						}
			
				}
				if (Input.GetKeyDown (KeyCode.Mouse0)) {
						Ray rayObj = MainCam.ScreenPointToRay (Input.mousePosition);
						if (Physics.Raycast (rayObj, out hitObject)) {
				
								hitObjName = hitObject.collider.name;
				
								switch (hitObjName) {
								case "CreditsBtn":
										SoundController.Static.PlayClickSound ();
										creditsBtnRender.material.mainTexture = creditsBtnTexture [1];
										break;
					
								case "MoreBtn":
										SoundController.Static.PlayClickSound ();
										moreBtnRender.material.mainTexture = moreBtnTexture [1];
										break;
					
								case "PlayBtn":
										SoundController.Static.PlayClickSound ();
										playBtnRender.material.mainTexture = playBtnTexture [1];
										break;
					
								case "ReviewBtn":
										SoundController.Static.PlayClickSound ();
										reviewBtnRender.material.mainTexture = reviewBtnTexture [1];
										break;
					
								case "StoreBtnBack":
										SoundController.Static.PlayClickSound ();
								//CreditsbackBtnRender.material.mainTexture = CreditsbackBtnTexture [1];
										StorebackBtnRender.material.mainTexture = StorebackBtnTexture [1];

										break;
								case "CreditsBtnBack":
										SoundController.Static.PlayClickSound ();
										CreditsbackBtnRender.material.mainTexture = CreditsbackBtnTexture [1];

					
										break;
								case "ExitBtn":
										SoundController.Static.PlayClickSound ();
										exitBtnRender.material.mainTexture = exitBtnTexture [1];
					
										break;
								case "StoreBtn":
										SoundController.Static.PlayClickSound ();
										StoreBtnRender.material.mainTexture = StoreBtnTexture [1];

				
										break;
					
								}
						}
			
				}
		
				 
		}
	
		void OriginalTextures ()
		{
				creditsBtnRender.material.mainTexture = creditsBtnTexture [0];
				moreBtnRender.material.mainTexture = moreBtnTexture [0];
				playBtnRender.material.mainTexture = playBtnTexture [0];
				StorebackBtnRender.material.mainTexture = StorebackBtnTexture [0];
				reviewBtnRender.material.mainTexture = reviewBtnTexture [0];
				CreditsbackBtnRender.material.mainTexture = CreditsbackBtnTexture [0];
				exitBtnRender.material.mainTexture = exitBtnTexture [0];
				StoreBtnRender.material.mainTexture = StoreBtnTexture [0];
		}

		void GamePlay ()
		{
		Application.LoadLevelAsync ("gameplay");
		//Application.LoadLevel("gameplay");
		}

}
