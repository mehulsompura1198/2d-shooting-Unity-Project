﻿using UnityEngine;
using System.Collections;

public class DestroyExplosive : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Destroy (gameObject,0.6f);
	}
	
	 
}
