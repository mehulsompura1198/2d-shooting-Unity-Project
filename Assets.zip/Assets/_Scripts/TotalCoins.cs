﻿using UnityEngine;
using System.Collections;

public class TotalCoins : MonoBehaviour {



	public static TotalCoins Static;
	public  TextMesh TotalCoinstext;
	int coinsIn;


	void Start () {
		UpdateCoins ();
		Static = this;
 

	}
	
	public  void UpdateCoins(){

		TotalCoinstext.text = ":" +  PlayerPrefs.GetInt ("TotalCoins", 0);
	}

	public void AddCoins(int AddingCoins){
		PlayerPrefs.SetInt ("TotalCoins", PlayerPrefs.GetInt ("TotalCoins", 0) + AddingCoins);
		UpdateCoins ();
	}
	public void SubtractCoins(int SubtractingCoins){
		PlayerPrefs.SetInt ("TotalCoins", PlayerPrefs.GetInt ("TotalCoins", 0) - SubtractingCoins);
		UpdateCoins ();
		}

	public int getCoinCount()
	{
		return PlayerPrefs.GetInt ("TotalCoins", 0);
	}

	void Update () {
//		if(Input.GetKeyDown(KeyCode.G))
//		{
//			int vol=1000;
//			AddCoins(vol);
//		}
//
//		if (Input.GetKeyDown (KeyCode.D))
//		{
//			PlayerPrefs.DeleteAll();
//		}
	
	}
}
