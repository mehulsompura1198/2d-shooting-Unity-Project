﻿using UnityEngine;
using System.Collections;

public class EnemyScript : MonoBehaviour {

	public float speed=0.2f;
	//public GameObject Enemy;
	public Transform  thisTrans;
	Vector3 originalScale ;
	int inverseScale =1;
	public Texture[] EnemyRunCycleTexture ;
	//public CharacterController EnemyController;
	//Vector3 moveDirection;
	public float gravity = 20.0F;
	public float  EnemyRunAnimSpeed ;
	public float textureCount;
	public Material EnemyMaterial;
	public bool isLimitsApplicable=false;
	public int health=2;

	void Start () {

		//EnemyController = GetComponent<CharacterController> ();
		thisTrans = transform;
		originalScale = thisTrans.localScale;

	}
	void EnemyAnimation(){
		if (textureCount > EnemyRunCycleTexture.Length - 1)
			textureCount = 0;
		EnemyMaterial.mainTexture = EnemyRunCycleTexture [Mathf.RoundToInt (textureCount)];
		textureCount += EnemyRunAnimSpeed;

		}
	// Update is called once per frame
	void Update () {

	//	if (PlayerController.isPlayerDead)
		//				return;
 
		thisTrans.Translate (-Vector3.right * speed*Time.deltaTime);
		EnemyAnimation ();
	}
	void OnTriggerEnter (Collider hit){
		if (hit.name.Contains ("limits") && isLimitsApplicable) {
						//print ("Trigger "+hit.name);
						inverseScale *= -1;
						thisTrans.localScale = new Vector3 (originalScale.x * inverseScale, originalScale.y, originalScale.z);
						speed *= -1;
				} else if (hit.name.Contains ("laser_gun5")) {
			               Destroy(gameObject);
			InGameUIController.Static.killCount++;
		}
	}
}
