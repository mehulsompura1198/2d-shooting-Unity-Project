﻿using UnityEngine;
using System.Collections;

public class LoadingRotation : MonoBehaviour {

	// Use this for initialization



	void Start () {
	
	}

	bool canRotate = false;

	void OnBecameVisible()
	{
		canRotate = true;
		}
	// Update is called once per frame
	void Update () {


		if( canRotate) transform.Rotate(Vector3.forward * -3);
	
	}
}
