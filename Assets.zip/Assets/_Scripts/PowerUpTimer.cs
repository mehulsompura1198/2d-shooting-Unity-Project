﻿using UnityEngine;
using System.Collections;
using System;
public class PowerUpTimer : MonoBehaviour {

	// Use this for initialization

	public Material progress;
	public TextMesh   countDown,tittleText;
	public static PowerUpTimer staticInst;
	public Color startColor,endColor;
	public GameObject scaler;

	public Vector3 StartPosition;
	void OnEnable()
	{
	 
		StartPosition = transform.localPosition;

		iTween.MoveTo(gameObject,iTween.Hash("position",new Vector3(-200,0,0 ),"time",1.0f,"easetype",iTween.EaseType.easeInOutBack,"delay",0.0f,"islocal",true) );
		 
	}
	void OnDisable()
	{
		 

	}
	void destroyTimer(System.Object obj,EventArgs args)
	{
		Destroy(gameObject);
	}
	void Start () {
		staticInst = this;
		 
	}

	
	// Update is called once per frame
 

	public void startCountDown(float timeLength)
	{
		 
		iTween.RotateTo(scaler,new Vector3(0,0,0),0);
		iTween.MoveTo(gameObject,iTween.Hash("islocal",false,"position",StartPosition,"time",0.5f,"easetype",iTween.EaseType.easeOutSine ) );//"isloacal",true

		Hashtable ht = iTween.Hash("from",timeLength,"to",0,"time",timeLength,"onupdate","ChangeTextValue","oncomplete","timerDone","islocal",true);
		iTween.ValueTo(gameObject,ht);

 

	}

	void ChangeTextValue(float countNumber)
	{
		countDown.text = ""+ Mathf.RoundToInt(countNumber);
	}
	void changeAlpha(float alphaValue)
	{
		progress.SetFloat("_Cutoff", alphaValue); 
	}

	void timerDone()
	{
		iTween.RotateTo(scaler,new Vector3(0,0,180),0.3f);
		iTween.MoveTo(gameObject,iTween.Hash("position",new Vector3(-200,0,0 ),"time",1.0f,"easetype",iTween.EaseType.easeInOutBack,"delay",0.0f,"islocal",true) );
	}
}
