﻿using UnityEngine;
using System.Collections;
 
public class InGameUIController : MonoBehaviour
{   

		public Camera InGameUICam;
		public string hitObjName;
		public int CollectedCoins;
		public int killCount;
		public float  finalCollectedCoins, finalDistance, coinsToDisplay;
		public TextMesh ingameCoinText, ingameDistanceText, IngameKilltext ;
		public GameObject finalScoreBoard, resumeMenu, pauseButton, FinalScoreCard, BgSoundObj, leftAnchor, rightAnchor, PowerupTimer, ShieldPower, Loadingmenu, NewBestDistance, JumpButton, AttackButton;
		public Vector3 playerPosition;
		public static InGameUIController Static;
		public bool isGamedEnded = false;
		public TextMesh finalCoinsText, finalDistanceText, BestDistanceText, ShieldCountText, lifeCountText, finalKillstext;
		public Renderer pauseBtnRender, homeBtnRender, GameOverhomeBtnRender, tryAgainBtnRender, GameOvertryAgainBtnRender, resumeBtnRender, JumpButtonRender, AttackButtonRender;
		public Texture[] pauseBtnTexture, homeBtnTexturer, GameOverhomeBtnTexture, tryAgainBtnTexture, GameOvertryAgainBtnTexture, resumeBtnTexture, JumpButtonTexture, AttackButtonTexture;
		Vector3 originalBestDistancePosition ;
		public int ShieldPowerCount;
		public bool shieldPoweActive = false;
		public int HelthCount = 3;
		public Material trailRender ;
		public bool isJumpButtonPressed = false, isAttackButtonPressed = false ;
		public GameObject Helth1, Helth2, Helth3;
		public GameObject TapToStart, Hud, GameOverBg, GameOver, CoinsObj, KillsObj, DistanceObj, BestdistanceObj, jumpText, attackText;
		public Material[] WorldMaterials;
		public Texture[] World1, World2, World3, World4;
		//public boatCamera cameraScript ;
		//public bool MagnetPowerActive=false;
		void OnEnable ()
		{
				sequence = Random.Range (1, 5);
				ChangeWorldTextures ();
		
				Vector2 screenAspectRatio = AspectRatio.GetAspectRatio (Screen.width, Screen.height);
		
				if (screenAspectRatio == new Vector2 (4, 3)) {
						//print ("leftanchor is moving");
			
						leftAnchor.transform.Translate (1.52f, 0.0f, 0.0f);
						rightAnchor.transform.Translate (-1.5f, 0.0f, 0.0f);
				}


				if (screenAspectRatio == new Vector2 (3, 2)) {
						//print ("leftanchor is moving");
			
						leftAnchor.transform.Translate (0.6f, 0.0f, 0.0f);
						rightAnchor.transform.Translate (-0.5f, 0.0f, 0.0f);
				}
				if (screenAspectRatio == new Vector2 (16, 10)) {
						leftAnchor.transform.Translate (0.0f, 0.0f, 0.0f);
						rightAnchor.transform.Translate (0.0f, 0.0f, 0.0f);
			
				}
				if (screenAspectRatio == new Vector2 (16, 9)) {
			
						leftAnchor.transform.Translate (-0.8f, 0.0f, 0.0f);
						rightAnchor.transform.Translate (0.7f, 0.0f, 0.0f);
				}
				if (screenAspectRatio == new Vector2 (5, 4)) {
						//print ("ScreenAspectratio");
						leftAnchor.transform.Translate (1.8f, 0.0f, 0.0f);
						rightAnchor.transform.Translate (-2.0f, 0.0f, 0.0f);
			
				}

				Hud.transform.localScale = Vector3.one * 5;
		}

		void Start ()
		{
				Static = this;
				resumeMenu.SetActive (false);
				originalBestDistancePosition = BestDistanceText.transform.localPosition;
				BestDistanceText.transform.Translate (40, 0, 0, Space.Self);
				Time.timeScale = 1;
				ShieldPowerCount = PlayerPrefs.GetInt ("ShieldCount", 0);
				Loadingmenu.SetActive (false);
				ShieldCountText.text = " " + ShieldPowerCount;
				NewBestDistance.SetActive (false);
		       
				iTween.ShakeRotation (TapToStart, iTween.Hash ("amount", new Vector3 (0.1f, 0.1f, 0.01f), "time", 0.3f, "Eesetype", iTween.EaseType.easeInOutBack, "looptype", iTween.LoopType.loop));

		}

		public void OnGameStart ()
		{
				iTween.ScaleTo (TapToStart, iTween.Hash ("scale", new Vector3 (3f, 3.001f, 2.001f), "time", 0.5f, "Eesetype", iTween.EaseType.easeInOutBack));	
				iTween.FadeTo (TapToStart, 0, 0.3f);
				Hud.SetActive (true);
				iTween.ScaleTo (Hud, iTween.Hash ("scale", new Vector3 (1f, 1f, 1f), "time", 0.9f, "Eesetype", iTween.EaseType.easeInOutExpo));	
		}

		void fianlCoinsCaliculations ()
		{

				iTween.ValueTo (gameObject, iTween.Hash ("from", 0,
		                                        "to", CollectedCoins,
		                                        "time", 0.5f,
		                                        "onUpdate", "showCoinScore", "delay", 0.9f));
				iTween.ValueTo (gameObject, iTween.Hash ("from", 0,
		                                         "to", killCount,
		                                         "time", 0.5f,
		                                         "onUpdate", "showKillsScore", "delay", 0.9f));


				iTween.ValueTo (gameObject, iTween.Hash ("from", 0,
		                                        "to", finalDistance,
		                                        "time", 0.5f,
		                                        "onUpdate", "showFinalDistance", "delay", 0.9f));

				if (PlayerPrefs.GetInt ("bestDistance", 0) < finalDistance) {
						//active new sticker obj here 
						NewBestDistance.SetActive (true);
						PlayerPrefs.SetInt ("bestDistance", Mathf.RoundToInt (finalDistance));
				}

				BestDistanceText.text = "   " + PlayerPrefs.GetInt ("bestDistance", 0);
				iTween.MoveTo (BestDistanceText.gameObject, iTween.Hash ("position", originalBestDistancePosition,
		                                                      "time", 0.5f, "delay", 1.95f,
		                                                      "easetype", iTween.EaseType.easeInOutExpo, "islocal", true));
				
				iTween.MoveTo (GameOverBg, iTween.Hash ("islocal", true, "position", new Vector3 (0.0f, 2.7f, -13.0f), "delay", 0.3f));
				iTween.MoveTo (GameOver, iTween.Hash ("islocal", true, "position", new Vector3 (0.0f, 2.8f, -18.0f), "delay", 0.5f));

				iTween.MoveTo (CoinsObj, iTween.Hash ("islocal", true, "position", new Vector3 (-0.21f, 0.5f, -16.0f), "delay", 0.9f));
				iTween.MoveTo (KillsObj, iTween.Hash ("islocal", true, "position", new Vector3 (-1.7f, -0.69f, -16.0f), "delay", 0.9f));
				iTween.MoveTo (DistanceObj, iTween.Hash ("islocal", true, "position", new Vector3 (-2.44f, -1.83f, -16.0f), "delay", 1.2f));
				iTween.MoveTo (BestdistanceObj, iTween.Hash ("islocal", true, "position", new Vector3 (-3.55f, -3.09f, -18.0f), "delay", 1.8f));
		
				PlayerPrefs.SetInt ("TotalCoins", PlayerPrefs.GetInt ("TotalCoins", 0) + CollectedCoins);
		}

		void showCoinScore (float value)
		{
				finalCoinsText.text = " " + Mathf.RoundToInt (value);
		}

		void showFinalDistance (float value)
		{
	 
				finalDistanceText.text = "" + Mathf.RoundToInt (value);
		}

		void showKillsScore (float value)
		{
				finalKillstext.text = " " + Mathf.RoundToInt (value);
		}

		RaycastHit hitObject;

		void Update ()
		{

				lifeCountText.text = "" + HelthCount;
				if (HelthCount == 0) {
						
						ongameEnded ();

						//PlayerController.currentState= PlayerController.PlayerStates.dead2;
						

				}
				
				switch (HelthCount) {
				case 1:
						Helth3.SetActive (false);
						Helth2.SetActive (false);
						break;
				case 2:
						Helth3.SetActive (false);
			    
						break;
				}

		
				if (Input.GetKeyUp (KeyCode.Escape)) {
						Application.LoadLevel ("Mainmenu");
				}
				if (!isGamedEnded) {
						
						finalDistance = Mathf.RoundToInt (PlayerController.PlayerCurrentPosition.x);
						ingameDistanceText.text = " Distance : " + finalDistance;
						ingameCoinText.text = "Coins : " + Mathf.RoundToInt (CollectedCoins);
						IngameKilltext.text = "Kills : " + Mathf.RoundToInt (killCount);
				}

				
				if (Input.GetKeyUp (KeyCode.Mouse0) && Input.touchCount == 0) {
						Originaltextures ();
						KeyUpState (Input.mousePosition);
				}
				if (Input.GetKeyDown (KeyCode.Mouse0) && Input.touchCount == 0) {
						KeyDownState (Input.mousePosition);
				}

				if (Input.GetKeyDown (KeyCode.Space)) {
						isJumpButtonPressed = true;
						iTween.PunchScale (JumpButton, iTween.Hash ("amount", new Vector3 (0.5f, 0.5f, 0.5f), "time", 0.5f));
				}
				if (Input.GetKeyDown (KeyCode.E)) {
						isAttackButtonPressed = true;
						iTween.PunchScale (AttackButton, iTween.Hash ("amount", new Vector3 (0.5f, 0.5f, 0.5f), "time", 0.5f));
				}
				//for touch input 

				foreach (Touch t in Input.touches) {

						if (t.phase == TouchPhase.Began) {
								KeyDownState (t.position);
						} else if (t.phase == TouchPhase.Ended) {
								//upstate 
								KeyUpState (t.position);
						}

				}
	
		}

		void KeyUpState (Vector2 positionUp)
		{
				Ray rayObj = InGameUICam.ScreenPointToRay (positionUp);
				if (Physics.Raycast (rayObj, out hitObject)) {
						hitObjName = hitObject.collider.name;
						switch (hitObjName) {
						case "pauseBtn":
								Time.timeScale = 0;
								ingameCoinText.gameObject.SetActive (false);
								ingameDistanceText.gameObject.SetActive (false);
								leftAnchor.SetActive (false);
								rightAnchor.SetActive (false);
								PowerupTimer.SetActive (false);
								pauseButton.SetActive (false);
								ShieldPower.SetActive (false);
								resumeMenu.SetActive (true);
								break;
						case "resumeBtn":
								ingameCoinText.gameObject.SetActive (true);
								ingameDistanceText.gameObject.SetActive (true);
								leftAnchor.SetActive (true);
								rightAnchor.SetActive (true);
			//PowerupTimer.SetActive (true);
								resumeMenu.SetActive (false);
								pauseButton.SetActive (true);
			//ShieldPower.SetActive (true);
								Time.timeScale = 1;

								break;
						case "TryAgainBtn":
								Time.timeScale = 1;
			//print ("Loading");
								Loadingmenu.SetActive (true);
								iTween.MoveTo (FinalScoreCard, iTween.Hash ("islocal", true, "position", new Vector3 (0.0f, 20.0f, 0.0f), "time", 0.5f));
				//iTween.MoveTo (Loadingmenu, iTween.Hash ("islocal", true, "position", new Vector3 (0, 0, 0),"ignoretimescale", true,"delay",0.5f, "time", 0.5f,"oncomplete","lateLoadLevel"));//"ignoretimescale", true,
			// Application.LoadLevel (Application.loadedLevelName);
								Invoke ("lateLoadLevel", 1.0f);
								resumeMenu.SetActive (false);
			
			
								break;
						case "HomeBtn":
								Time.timeScale = 1;
								Invoke ("LoadLevel", 1.0f);
								Loadingmenu.SetActive (true);
								resumeMenu.SetActive (false);
								iTween.MoveTo (FinalScoreCard, iTween.Hash ("islocal", true, "position", new Vector3 (0.0f, 20.0f, 0.0f), "time", 0.5f));
				
								break;
						case "JumpButton":
								isJumpButtonPressed = true;
								iTween.PunchScale (JumpButton, iTween.Hash ("amount", new Vector3 (0.5f, 0.5f, 0.5f), "time", 0.5f));
								if (jumpText.activeSelf)
										jumpText.SetActive (false);
								break;
						case "AttackButton":
								isAttackButtonPressed = true;
								iTween.PunchScale (AttackButton, iTween.Hash ("amount", new Vector3 (0.5f, 0.5f, 0.5f), "time", 0.5f));
								hitObject.collider.transform.Rotate (0, 0, -30);
								if (attackText.activeSelf)
										attackText.SetActive (false);
								break;
			           
						case "ShiledPickUp":
			
								if (ShieldPowerCount > 0 && !PlayerController.Static.isShieldOn) {
										GameObject.FindGameObjectWithTag ("Player").SendMessage ("ActivateShield", SendMessageOptions.DontRequireReceiver);
										PowerUpTimer.staticInst.startCountDown (20f);		
										ShieldPowerCount --;
										PlayerPrefs.SetInt ("ShieldCount", PlayerPrefs.GetInt ("ShieldCount", 1) - 1);
										ShieldCountText.text = " " + ShieldPowerCount;
								} else {
										//punch power scale 
								}
			
								break;
						}
				}
		}

		void KeyDownState (Vector2 position)
		{
				Ray rayObj = InGameUICam.ScreenPointToRay (position);
				if (Physics.Raycast (rayObj, out hitObject)) {
			
						hitObjName = hitObject.collider.name;
			
						switch (hitObjName) {
						case "pauseBtn":
								SoundController.Static.PlayClickSound ();
				
								pauseBtnRender.material.mainTexture = pauseBtnTexture [1];
								break;
						case "resumeBtn":
								SoundController.Static.PlayClickSound ();
				//					                   
				
								resumeBtnRender.material.mainTexture = resumeBtnTexture [1];
				
								break;
						case "TryAgainBtn":
//								PlayerController.Static.gun1text ();
								SoundController.Static.PlayClickSound ();
								tryAgainBtnRender.material.mainTexture = tryAgainBtnTexture [1];
								GameOvertryAgainBtnRender.material.mainTexture = GameOvertryAgainBtnTexture [1];
				//					                   
				
								break;
						case "HomeBtn":
				//print ("texture change");
								SoundController.Static.PlayClickSound ();
								homeBtnRender.material.mainTexture = homeBtnTexturer [1];
								GameOverhomeBtnRender.material.mainTexture = GameOverhomeBtnTexture [1];
								break;
						case "ShiledPickUp":
								SoundController.Static.PlayClickSound ();
								break;
						case "JumpButton":
								isJumpButtonPressed = false;
								JumpButtonRender.material.mainTexture = JumpButtonTexture [1];
								break;
						case "AttackButton":
								isAttackButtonPressed = false;
								AttackButtonRender.material.mainTexture = AttackButtonTexture [1];
								break;
						}
				}
		}
	
		public void UpdateInGameCoinCount ()
		{
				CollectedCoins++;
				ingameCoinText.text = "Coins : " + CollectedCoins;
		}

		bool justOnce = false;

		public void ongameEnded ()
		{
				if (justOnce)
						return;

				GameController.Static.StopInstantiate ();
				justOnce = true;
				GameObject.Find ("worldBackground").GetComponent<UVScrolling> ().enabled = false;
				GameObject.Find ("BgSound").GetComponent<AudioSource> ().enabled = false;
				PlayerController.Static.speed = 0;
				//	PlayerController.Static.guntextchange ();
	         
	         
				GameObject.Find ("Main Camera").GetComponent<Camerafollow> ().enabled = false;
				GameController.Static.StopInstantiate ();
				isGamedEnded = true;
				DisableIngameUI ();
				EnableFinalScoreUI ();

				iTween.MoveTo (FinalScoreCard, iTween.Hash ("islocal", true, "position", Vector3.zero, "time", 0.5f, "delay", 0.2f));
				//iTween.MoveTo (GameOverBg, new Vector3 (0,2.8f,-13),0.2f);
				//iTween.MoveTo (GameOver, new Vector3 (0,2.9f,-18), 0.4f);
				//isCreateNewCoins =false;
				//BgSoundObj.GetComponent<AudioSource> ().enabled = false;
				PlayerController.currentState = PlayerController.PlayerStates.dead;

		}
		
		public void EnableFinalScoreUI ()
		{
				finalScoreBoard.SetActive (true);
				fianlCoinsCaliculations ();
				//PowerupTimer.SetActive (true);
		}

		public void DisableIngameUI ()
		{
				ingameCoinText.gameObject.SetActive (false);
				ingameDistanceText.gameObject.SetActive (false);
				pauseButton.SetActive (false);
				leftAnchor.SetActive (false);
				rightAnchor.SetActive (false);
				PowerupTimer.SetActive (false);
				ShieldPower.SetActive (false);

		}

		public void Originaltextures ()
		{
				homeBtnRender.material.mainTexture = homeBtnTexturer [0];
				resumeBtnRender.material.mainTexture = resumeBtnTexture [0];
				tryAgainBtnRender.material.mainTexture = tryAgainBtnTexture [0];
				GameOvertryAgainBtnRender.material.mainTexture = GameOvertryAgainBtnTexture [0];
				GameOverhomeBtnRender.material.mainTexture = GameOverhomeBtnTexture [0];
				JumpButtonRender.material.mainTexture = JumpButtonTexture [0];
				AttackButtonRender.material.mainTexture = AttackButtonTexture [0];
				pauseBtnRender.material.mainTexture = pauseBtnTexture [0];
		}

		float lastWorld = 0 ;
		int sequence = 1;

		public void ChangeWorldTextures ()
		{
				if (sequence > 4)
						sequence = 1;		  

				 
				switch (sequence) {
				case 1:
						for (int i=0; i <= 3; i++) {
								WorldMaterials [i].mainTexture = World1 [i];
						}
			
						break;
				case 2:
						for (int i=0; i <= 3; i++) {
								WorldMaterials [i].mainTexture = World2 [i];
						}
			
						break;
				case 3:
						for (int i=0; i <= 3; i++) {
								WorldMaterials [i].mainTexture = World3 [i];
						}
						break;
				case 4:
						for (int i=0; i <= 3; i++) {
								WorldMaterials [i].mainTexture = World4 [i];
						}

						break;
		 
			
				}
				sequence++;
		
		}

		public GameObject powerShow ;
		public Material powerIconMaterial;
		public Texture[] powerIconTextures;
		public Animation powerAnimation ;

		public void showPowerDisplay ()
		{
				powerShow.SetActive (true);
				GameController.Static.stopGameplay = true;
				powerAnimation.Play ();

				switch (PlayerController.currentGunType) {

				case PlayerController.GunType.gun2:
						powerIconMaterial.mainTexture = powerIconTextures [0];
						break;
				case PlayerController.GunType.gun3:
						powerIconMaterial.mainTexture = powerIconTextures [1];
						break;
				case PlayerController.GunType.gun4:
						powerIconMaterial.mainTexture = powerIconTextures [2];
						break;
				case PlayerController.GunType.gun5:
						powerIconMaterial.mainTexture = powerIconTextures [3];
						break;
				}

				Invoke ("stopPowerDisplay", 2.0f);

		}

		public void stopPowerDisplay ()
		{
				GameController.Static.stopGameplay = false;
				powerAnimation.Stop ();
				powerShow.SetActive (false);
		}

		void  lateLoadLevel ()
		{
		 
				Application.LoadLevel (Application.loadedLevelName);
		}

		void LoadLevel ()
		{
				Application.LoadLevel ("Mainmenu");
		}

}
