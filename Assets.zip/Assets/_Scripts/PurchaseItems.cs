﻿using UnityEngine;
using System.Collections;

public class PurchaseItems : MonoBehaviour
{

		public Camera Cam;
		public string hitObjName;
		public int ShieldCost = 200;
		public int MagnetCost = 100;
		public int Gun2BulletCost = 100;
		public int Gun3BulletCost = 200;
		public int Gun4BulletCost = 300;
		public int Gun5BulletCost = 400;
		public GameObject insufficentCoins;
		public TextMesh ShieldCountTxt, Gun2BulletCount, Gun3BulletCount, Gun4BulletCount, Gun5BulletCount;
		public GameObject MagnetPower1, MagnetPower2, MagnetPower3, MagnetPower4;
		public Renderer BuyShieldRender, BuyMagnetRender, BuyGun2BulletRender, BuyGun3BulletRender, BuyGun4BulletRender, BuyGun5BulletRender,CloseBtnRender;
	    public Texture[] BuyShieldTexture, BuyMagnetTexture, BuyGun2BulletTexture, BuyGun3BulletTexture, BuyGun4BulletTexture, BuyGun5BulletTexture,CloseBtnTexture;
		//MagnetCountTet;
	
		void Start ()
		{


				Gun2BulletCount.text = "" + PlayerPrefs.GetInt ("Gun2BulletCount", 0);
				Gun3BulletCount.text = "" + PlayerPrefs.GetInt ("Gun3BulletCount", 0);
				Gun4BulletCount.text = "" + PlayerPrefs.GetInt ("Gun4BulletCount", 0);
				Gun5BulletCount.text = "" + PlayerPrefs.GetInt ("Gun5BulletCount", 0);

				#if UNITY_EDITOR
	
    // PlayerPrefs.DeleteAll ();
//		TotalCoins.Static.AddCoins (200000);
				#endif

				ShieldCountTxt.text = "" + PlayerPrefs.GetInt ("ShieldCount", 0);
	 
				//	print (PlayerPrefs.GetInt ("MagnetCount", 0));
				switch (PlayerPrefs.GetInt ("MagnetCount", 0)) {
				case 0:
						MagnetPower1.SetActive (false);
						MagnetPower2.SetActive (false);
						MagnetPower3.SetActive (false);
						MagnetPower4.SetActive (false);
			 
						break;
			
				case 1:
						MagnetPower1.SetActive (true);
						MagnetPower2.SetActive (false);
						MagnetPower3.SetActive (false);
						MagnetPower4.SetActive (false);
			 
						break;
				case 2:
						MagnetPower1.SetActive (true);
						MagnetPower2.SetActive (true);
						MagnetPower3.SetActive (false);
						MagnetPower4.SetActive (false);
			 
						break;
				case 3:
						MagnetPower1.SetActive (true);
						MagnetPower2.SetActive (true);
						MagnetPower3.SetActive (true);
						MagnetPower4.SetActive (false);
			 
						break;
				case 4:
						MagnetPower1.SetActive (true);
						MagnetPower2.SetActive (true);
						MagnetPower3.SetActive (true);
						MagnetPower4.SetActive (true);
			 
						break;
				}
		
		}
	
		void Update ()
		{
				if (Input.GetKeyUp (KeyCode.Mouse0)) {
						BuyShieldRender.material.mainTexture = BuyShieldTexture [0];
						BuyMagnetRender.material.mainTexture = BuyMagnetTexture [0];
						BuyGun2BulletRender.material.mainTexture = BuyGun2BulletTexture [0];
						BuyGun3BulletRender.material.mainTexture = BuyGun3BulletTexture [0];
						BuyGun4BulletRender.material.mainTexture = BuyGun4BulletTexture [0];
						BuyGun5BulletRender.material.mainTexture = BuyGun5BulletTexture [0];

						Ray rayObj = Cam.ScreenPointToRay (Input.mousePosition);
						RaycastHit hitObject;
			
						if (Physics.Raycast (rayObj, out hitObject) ) {
								hitObjName = hitObject.collider.name;
			

							
								switch (hitObjName) {
				
								case "BuyShieldt":
										if (TotalCoins.Static.getCoinCount () >= ShieldCost) { 
												PlayerPrefs.SetInt ("ShieldCount", PlayerPrefs.GetInt ("ShieldCount", 0) + 1);
												ShieldCountTxt.text = "" + PlayerPrefs.GetInt ("ShieldCount", 0);
												TotalCoins.Static.SubtractCoins (ShieldCost);
					
										} else {
						insufficentCoins.SetActive(true);
										}
				
										break;
								case "BuyGun2Bullet":
										if (TotalCoins.Static.getCoinCount () >= Gun2BulletCost) { 
												if ( PlayerPrefs.GetInt ("Gun2BulletCount", 0) == 5)
														return;
												PlayerPrefs.SetInt ("Gun2BulletCount", PlayerPrefs.GetInt ("Gun2BulletCount", 1) + 1);
						Gun2BulletCount.text = "" + PlayerPrefs.GetInt ("Gun2BulletCount", 0)*10;
												TotalCoins.Static.SubtractCoins (Gun2BulletCost);
						
										} else {
						insufficentCoins.SetActive(true);
										}
					
										break;

								case "BuyGun3Bullet":
										if (TotalCoins.Static.getCoinCount () >= Gun3BulletCost) { 
												if ( PlayerPrefs.GetInt ("Gun3BulletCount", 0) == 5)
														return;
												PlayerPrefs.SetInt ("Gun3BulletCount", PlayerPrefs.GetInt ("Gun3BulletCount", 1) + 1);
						Gun3BulletCount.text = "" + PlayerPrefs.GetInt ("Gun3BulletCount", 0)*10;
												TotalCoins.Static.SubtractCoins (Gun3BulletCost);
						
										} else {
						insufficentCoins.SetActive(true);
										}
					
										break;

								case "BuyGun4Bullet":
										if (TotalCoins.Static.getCoinCount () >= Gun4BulletCost) { 
												if ( PlayerPrefs.GetInt ("Gun4BulletCount", 0) == 5)
														return;
												PlayerPrefs.SetInt ("Gun4BulletCount", PlayerPrefs.GetInt ("Gun4BulletCount", 1) + 1);
						Gun4BulletCount.text = "" + PlayerPrefs.GetInt ("Gun4BulletCount", 0)*10;
												TotalCoins.Static.SubtractCoins (Gun4BulletCost);
						
										} else {
						insufficentCoins.SetActive(true);
										}
					
										break;

								case "BuyGun5Bullet":
										if (TotalCoins.Static.getCoinCount () >= Gun5BulletCost) { 
												if ( PlayerPrefs.GetInt ("Gun5BulletCount", 0) == 5)
														return;
												PlayerPrefs.SetInt ("Gun5BulletCount", PlayerPrefs.GetInt ("Gun5BulletCount", 1) + 1);
						Gun5BulletCount.text = "" + PlayerPrefs.GetInt ("Gun5BulletCount", 0)*10;
												TotalCoins.Static.SubtractCoins (Gun5BulletCost);
						
										} else {
						insufficentCoins.SetActive(true);
										}
					
										break;
								case "BuyMagnet":

										if (TotalCoins.Static.getCoinCount () >= MagnetCost && PlayerPrefs.GetInt ("MagnetCount", 0) <= 3) {
												print ("Magnet activated");

												PlayerPrefs.SetInt ("MagnetCount", PlayerPrefs.GetInt ("MagnetCount") + 1);
												TotalCoins.Static.SubtractCoins (MagnetCost);
												switch (PlayerPrefs.GetInt ("MagnetCount", 0)) {
												case 0:
														MagnetPower1.SetActive (false);
														MagnetPower2.SetActive (false);
														MagnetPower3.SetActive (false);
														MagnetPower4.SetActive (false);
						//PlayerPrefs.SetInt("MagnetCount",PlayerPrefs.GetInt("MagnetCount",0)+10);
														break;
						
												case 1:
														MagnetPower1.SetActive (true);
														MagnetPower2.SetActive (false);
														MagnetPower3.SetActive (false);
														MagnetPower4.SetActive (false);
							//PlayerPrefs.SetInt("MagnetCount",PlayerPrefs.GetInt("MagnetCount",10)+10);
														break;
												case 2:
														MagnetPower1.SetActive (true);
														MagnetPower2.SetActive (true);
														MagnetPower3.SetActive (false);
														MagnetPower4.SetActive (false);
						//PlayerPrefs.SetInt("MagnetCount",PlayerPrefs.GetInt("MagnetCount",10)+10);
														break;
												case 3:
														MagnetPower1.SetActive (true);
														MagnetPower2.SetActive (true);
														MagnetPower3.SetActive (true);
														MagnetPower4.SetActive (false);
						//PlayerPrefs.SetInt("MagnetCount",PlayerPrefs.GetInt("MagnetCount",10)+10);
														break;
												case 4:
														MagnetPower1.SetActive (true);
														MagnetPower2.SetActive (true);
														MagnetPower3.SetActive (true);
														MagnetPower4.SetActive (true);
						//PlayerPrefs.SetInt("MagnetCount",PlayerPrefs.GetInt("MagnetCount",10)+10);
														break;
												}

					
										}
					else {
						insufficentCoins.SetActive(true);
					}
										break;
				                        case "CloseButton":
				                        insufficentCoins.SetActive(false);
					                    CloseBtnRender.material.mainTexture=CloseBtnTexture[0];
										break;
								}
						}

				}
				
		
				if (Input.GetKeyDown (KeyCode.Mouse0)) {

						Ray rayObj = Cam.ScreenPointToRay (Input.mousePosition);
						RaycastHit hitObject;
			
						if (Physics.Raycast (rayObj, out hitObject)) {
								hitObjName = hitObject.collider.name;

								switch (hitObjName) {
				
								case "BuyShieldt":
										SoundController.Static.PlayClickSound ();

										BuyShieldRender.material.mainTexture = BuyShieldTexture [1];
										break;
				
								case "BuyMagnet":
										SoundController.Static.PlayClickSound ();

										BuyMagnetRender.material.mainTexture = BuyMagnetTexture [1];
										break;
								case "BuyGun2Bullet":
					BuyGun2BulletRender.material.mainTexture = BuyGun2BulletTexture [1];
					SoundController.Static.PlayClickSound ();
										break;
								case "BuyGun3Bullet":
					BuyGun3BulletRender.material.mainTexture = BuyGun3BulletTexture [1];
					SoundController.Static.PlayClickSound ();
										break;
								case "BuyGun4Bullet":
					BuyGun4BulletRender.material.mainTexture = BuyGun4BulletTexture [1];
					SoundController.Static.PlayClickSound ();
										break;
								case "BuyGun5Bullet":
					BuyGun5BulletRender.material.mainTexture = BuyGun5BulletTexture [1];
					SoundController.Static.PlayClickSound ();
										break;
				case "CloseButton":
					CloseBtnRender.material.mainTexture=CloseBtnTexture[1];
					SoundController.Static.PlayClickSound ();
					break;
								}
						}
				}

		}

		//if(PlayerPrefs.GetInt ("Gun1BulletCount", 0)>=5)return;
		

}
